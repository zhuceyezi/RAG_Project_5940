import streamlit as st
from openai import OpenAI
import openai
from pydantic import BaseModel, Field
from utils import Player, Agent, roll_dice, run_full_turn, apply_hp_effects, extract_hp_effect_from_text, render_sidebar
from typing import Dict
import json

# === Set up OpenAI client ===
client = OpenAI(
    api_key="sk-xIvD5Mw4sc1_owNpoJcO8g",
    base_url="https://api.ai.it.cornell.edu/"
)

# === Set up session state ===
if "chat_log" not in st.session_state:
    st.session_state.chat_log = []

if "players" not in st.session_state or not isinstance(list(st.session_state.players.values())[0], Player):
    st.session_state.players = {
        "Aragorn": Player(name="Aragorn", max_hp=30, hp=30),
        "Frodo": Player(name="Frodo", max_hp=20, hp=20)
    }


# === Define the agent using your helper class ===
agent = Agent(
    name="DungeonMaster",
    model="openai.gpt-4o",
    instructions=(
        "You are a Dungeons & Dragons Dungeon Master. Narrate what happens. "
        "When a player heals or takes damage, use the `roll_dice` tool directly. "
        "Do not ask for permission to roll. Use it when needed and let the system apply the result."
    ),
    tools=[roll_dice],
    players=st.session_state.players
)

# === Streamlit UI ===
st.title("🧙 D&D Chat with Dice Rolls")
st.caption("Powered by Azure OpenAI + Tool Calling")


# === Display chat log ===
for msg in st.session_state.chat_log:
    role = msg["role"] if isinstance(msg, dict) else msg.role
    content = msg["content"] if isinstance(msg, dict) else msg.content

    if content is None or role == "tool":
        continue  # hide tool result content

    with st.chat_message(role):
        st.markdown(content)




def apply_and_render_hp_effects(client, assistant_messages, players):
    """Calls GPT to extract and apply HP effects, then re-renders sidebar."""
    try:
        apply_hp_effects(client, tool_outputs=[], assistant_messages=assistant_messages, players=players)
    except Exception as e:
        st.warning(f"❌ Failed to apply HP effects: {e}")




# === Chat input ===
if prompt := st.chat_input("What happens next?"):
    st.session_state.chat_log.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # Run GPT with tool support
    new_messages, tool_outputs = run_full_turn(client, agent, st.session_state.chat_log)
    st.session_state.chat_log.extend(new_messages)

    # Display assistant messages in bubbles
    for msg in new_messages:
        role = msg["role"] if isinstance(msg, dict) else msg.role
        content = msg["content"] if isinstance(msg, dict) else msg.content

        if content is None:
            continue  # Skip messages with no displayable content

        with st.chat_message(role):
            st.markdown(content)
    # Apply effects like healing or damage
    apply_hp_effects(client, new_messages, agent.players)

render_sidebar(agent.players)